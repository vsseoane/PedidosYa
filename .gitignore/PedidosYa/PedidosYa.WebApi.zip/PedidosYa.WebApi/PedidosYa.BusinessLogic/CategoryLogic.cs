﻿using PedidosYa.DataAccess;
using PedidosYa.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PedidosYa.BusinessLogic
{
    public class CategoryLogic
    {
        public void CreateCategory(Category aCategory)
        {
            try
            {
                using (PersistentDbContext context = new PersistentDbContext())
                {
                    context.Set<Category>().Add(aCategory);
                    context.SaveChanges();
                }
            }
            catch (Exception e)
            {
                throw new Exception(e.ToString());
            }
        }
    }
}
