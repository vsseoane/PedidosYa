﻿using PedidosYa.DataAccess;
using PedidosYa.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PedidosYa.BusinessLogic
{
    public class RestaurantLogic
    {

        public void CreateRestaurant(Restaurant aRestaurant)
        {
            try
            {
                using (PersistentDbContext context = new PersistentDbContext())
                {
                   /* List<Category> categories = aRestaurant.Categories;
                    foreach (var category in categories)
                    {
                        context.Categories.Add(category);
                    }*/
                    
                    context.Set<Restaurant>().Add(aRestaurant);
                    context.SaveChanges();
                }
            }
            catch (Exception e)
            {
                throw new Exception(e.ToString());
            }
           

            
        }
    }
}
