﻿using PedidosYa.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PedidosYa.DataAccess
{
    public class PersistentDbContext : DbContext
    {
        public PersistentDbContext() : base("name=PedidosYa") { }
        public DbSet<Restaurant> Restaurants { get; set; }
        public DbSet<Category> Categories { get; set; }
    }
}
