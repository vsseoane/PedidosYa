﻿using PedidosYa.BusinessLogic;
using PedidosYa.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace PedidosYa.WebApi.Controllers
{
    public class RestaurantController : ApiController
    {
        RestaurantLogic restaurantLogic = new RestaurantLogic();
        // GET: api/Restaurant
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET: api/Restaurant/5
        public string Get(int id)
        {
            return "value";
        }

        // POST: api/Restaurant
        [HttpPost]
        public IHttpActionResult Post([FromBody]Restaurant restaurant)
        {
            try
            {
                restaurantLogic.CreateRestaurant(restaurant);
                return Ok();
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }

        }

        // PUT: api/Restaurant/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE: api/Restaurant/5
        public void Delete(int id)
        {
        }
    }
}
